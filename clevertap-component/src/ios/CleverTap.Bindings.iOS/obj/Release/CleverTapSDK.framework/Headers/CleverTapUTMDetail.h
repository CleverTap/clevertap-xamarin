#import <Foundation/Foundation.h>

@interface CleverTapUTMDetail : NSObject
@property(nonatomic, strong) NSString *source;
@property(nonatomic, strong) NSString *medium;
@property(nonatomic, strong) NSString *campaign;
@end
