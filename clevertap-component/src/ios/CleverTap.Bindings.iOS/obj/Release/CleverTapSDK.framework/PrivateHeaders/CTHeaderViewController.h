#import "CTBaseHeaderFooterViewController.h"

@interface CTHeaderViewController : CTBaseHeaderFooterViewController

@end
