#import "CTInAppDisplayViewController.h"

@interface CTInterstitialImageViewController : CTInAppDisplayViewController

@end
