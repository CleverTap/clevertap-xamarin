#import "CTImageInAppViewController.h"

@interface CTCoverImageViewController : CTImageInAppViewController

@end

