#import "CTImageInAppViewController.h"

@interface CTHalfInterstitialImageViewController : CTImageInAppViewController

@end

