#import "CTInAppDisplayViewController.h"

@interface CTInAppHTMLViewController : CTInAppDisplayViewController

- (instancetype)initWithNotification:(CTInAppNotification *)notification config:(CleverTapInstanceConfig *)config;

@end
