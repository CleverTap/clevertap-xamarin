
#import "CTImageInAppViewController.h"

@interface CTInterstitialImageViewController : CTImageInAppViewController

@end
