#import "CTInAppDisplayViewController.h"

@interface CTInAppHTMLViewController : CTInAppDisplayViewController

@end
